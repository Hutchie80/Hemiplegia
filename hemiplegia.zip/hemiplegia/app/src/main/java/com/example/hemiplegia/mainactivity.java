package com.example.hemiplegia;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class mainactivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth ;
    private ProgressBar progressBar ;
    private DatabaseReference mDatabase;
    private View view;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainactivity);
        firebaseAuth =FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("Reports");
        //welcome message
        welcome_message();
    }

    public void display_user_details(View view){
        startActivity(new Intent( mainactivity.this, userdetails.class));
    }
    public void display_schedule(View view){
        startActivity(new Intent( mainactivity.this, schedule.class));
    }
    public void display_reports(View view){
        startActivity(new Intent( mainactivity.this, reports.class));
    }

    public void basicRead(String email){
        // if string in json email, matches string email
        // display that firstname and surname in Welcome message;

    }
    public void user_Logout(View view) {
        firebaseAuth.signOut();
        finish();
        startActivity(new Intent( mainactivity.this, loginactivity.class));
    }
    public void welcome_message() {
        final TextView textViewWelcome = (TextView) findViewById(R.id.userWelcome);
        mDatabase.addValueEventListener(new ValueEventListener() {@Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            if (dataSnapshot.exists()) {
                HashMap<String, Object> dataMap = (HashMap<String, Object>) dataSnapshot.getValue();
                try {
                    String first = String.valueOf(dataMap.get("First name"));
                    String surname = String.valueOf(dataMap.get("Surname"));
                    String name = first + surname;
                    String Welcome = "Welcome " + name + ".";
                    textViewWelcome.setText(Welcome);
                } catch (ClassCastException err) {
                    FirebaseUser currentUser = firebaseAuth.getCurrentUser();
                    String email = currentUser.getEmail();
                    String Welcome = "Welcome " + currentUser.getEmail() + ".";
                    textViewWelcome.setText(Welcome);
                }
            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {
        }
        }
        );
    }
}

