package com.example.hemiplegia;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class left_right extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private DatabaseReference mDatabase;
    private TextView leftText;
    private TextView rightText;
    private TextView RightorLeft;
    private int pressure = 250;
    private ProgressBar progressBar;
    private String Paralysis = "RIGHT";
    private String ArmSelection;
    private String Dbpressure;
    private boolean Arm_selection;
    private Intent intent;
    private DatabaseReference mData;
    private BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
   //duration of time requested
    private static final int DISCOVER_DURATION = 300;

    // our request code (must be greater than zero)
    private static final int REQUEST_BLU = 1;

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leftright);
        mData = FirebaseDatabase.getInstance().getReference("Reports");
        make_invisible();
        bluetooth_check();
        intent = new Intent();
        intent_cal();
        Arm_selection = left_or_right();
        String Name = getLocalBluetoothName();
        Toast.makeText(this, "Bluetooth Device: "+ Name,  Toast.LENGTH_LONG).show();
        database_select();
    }

    private void database_select() {
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    HashMap<String, Object> dataMap = (HashMap<String, Object>) dataSnapshot.getValue();
                    Paralysis = String.valueOf(dataMap.get("Hemiplegia"));
                    Dbpressure = String.valueOf(dataMap.get("first"));
                    Dbpressure = Dbpressure + ", " + pressure;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Paralysis = "LEFT";
                Toast.makeText(getApplicationContext(), "Some Errors Have Occurred", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void intent_cal() {
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File("file_to_transfer")) );

        //...
        startActivity(intent);
        //list of apps that can handle our intent
        PackageManager pm = getPackageManager();
        List appsList = pm.queryIntentActivities(bluetooth_run(),0);
        //select bluetooth
        String packageName = null;
        String className = null;
        ArrayList<ResolveInfo> list = (ArrayList<ResolveInfo>) appsList;
        boolean found = false;
        if(appsList.size() > 0 ){
            // proceed
            for(ResolveInfo info: list ){
                packageName = info.activityInfo.packageName;
                if( packageName.equals("com.android.bluetooth")){
                    className = info.activityInfo.name;
                    found = true;
                    break;// found
                }
            }
            if(! found){
                Toast.makeText(this, "blu_notfound_inlist", Toast.LENGTH_SHORT).show();
                // exit
            }
            //set our intent to launch Bluetooth
            intent.setClassName(packageName, className);
            startActivity(intent);
        }
    }


    public void onActivtyResults (int requestCode, int resultCode, Intent data) {

        if (resultCode == DISCOVER_DURATION
                && requestCode == REQUEST_BLU) {

            // processing code goes here
        }
        else{ // cancelled or error
            Toast.makeText(this, "blu_cancelled",
                    Toast.LENGTH_SHORT).show();
        }

    }
    private Intent bluetooth_run() {
        setContentView(R.layout.leftright);
        View view = findViewById(android.R.id.content);
        Intent returnIntent = new Intent();
        returnIntent = new Intent( view.getContext(), left_right.class);
        return returnIntent;
    }

    public boolean left_or_right() {
        boolean reach = false;
        int max = 99;
        int min = 1;
        Random r = new Random();
        int randomise = r.nextInt(max + 1);

        if (randomise % 2 == 0) {
            rightText.setVisibility(View.VISIBLE);
            String Right = getString(R.string.RightHand);
            RightorLeft.setText(Right);
            RightorLeft.setVisibility(View.VISIBLE);
            ArmSelection = "RIGHT";
            reach = true;
        } else {
            leftText.setVisibility(View.VISIBLE);
            String Left = getString(R.string.LeftHand);
            RightorLeft.setText(Left);
            RightorLeft.setVisibility(View.VISIBLE);
            ArmSelection = "LEFT";
            reach = true;
        }
        return reach;
    }

    public void make_invisible() {
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        leftText = (TextView) findViewById(R.id.LeftHand);
        leftText.setVisibility(View.GONE);
        rightText = (TextView) findViewById(R.id.RightHand);
        rightText.setVisibility(View.GONE);
        RightorLeft = (TextView) findViewById(R.id.rightorleft);
        RightorLeft.setVisibility(View.GONE);

    }

    public void display_home(View view) {
        startActivity(new Intent(left_right.this, schedule.class));
        finish();
    }

    public void bluetooth_check() {
        BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();

        if(btAdapter ==null)
        {
            Toast.makeText(this," Device doesn't support Bluetooth ", Toast.LENGTH_LONG).show();
            // Inform user that we're done.
            Toast.makeText(this," Please Press Stop! Your Device doesn't support Bluetooth ", Toast.LENGTH_LONG).show();
        }
    }
    public String getLocalBluetoothName(){
        if(btAdapter == null){
            btAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        String name = btAdapter.getName();
        if(name == null){
            System.out.println("Name is null!");
            name = btAdapter.getAddress();
        }
        return name;
    }

    public void pressStart(View view) {

        if (Arm_selection == true) {
            if (pressure > 200) {

                startActivity(new Intent(left_right.this, videoview.class));
                finish();
            }
        }
    }

    public void enableBlu(){
        // enable device discovery - this will automatically enable Bluetooth
        Intent discoveryIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);

        discoveryIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION,
                DISCOVER_DURATION );

        startActivityForResult(discoveryIntent, REQUEST_BLU);
    }
}