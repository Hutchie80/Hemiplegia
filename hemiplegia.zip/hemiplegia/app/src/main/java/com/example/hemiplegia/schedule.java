package com.example.hemiplegia;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;

import java.util.ArrayList;
import java.util.HashMap;

public class schedule extends AppCompatActivity {
    private View view;
    private ProgressBar progressBar;
    private CalendarView mCalendarview;
    private DatabaseReference mDatabase;
    private MaterialCalendarView calendar;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);
        mCalendarview = findViewById(R.id.calendarView);
        MaterialCalendarView calendar = findViewById(R.id.calendar_view);
        initializeCal();


    }

    public void initializeCal() {
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    HashMap<String, Object> dataMap = (HashMap<String, Object>) dataSnapshot.getValue();
                    String dateCompleted = String.valueOf(dataMap.get("Date"));
                    //load into page
                    String[] Dates = dateCompleted.split(",");

                    ArrayList<CalendarDay> ArrayDates = new ArrayList<>();
                    CalendarDay a = null;
                    for (int i = 0; i < Dates.length; i++) {
                        String Day = Dates[i].toString();
                        String[] dateSplit = Day.split("/");
                        if (dateSplit.length == 3) {
                            int Year = Integer.parseInt(dateSplit[2]);
                            int Month = Integer.parseInt(dateSplit[1]);
                            int Day_end = Integer.parseInt(dateSplit[0]);
                            a = CalendarDay.from(Year, Month, Day_end);
                            ArrayDates.set(i, a);
                            calendar.addDecorators(new EventDecorator(schedule.this, ArrayDates));
                        } else {
                            a = CalendarDay.from(2020, 04, 23);
                            ArrayDates.set(i, a);
                            calendar.addDecorators(new EventDecorator(schedule.this, ArrayDates));

                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                String LoadFailed = "Data failed to Load in Date";
                Toast.makeText(getApplicationContext(), "Some Errors Have Occurred" + LoadFailed, Toast.LENGTH_LONG).show();
            }
        });
    }
    //use event decorator to mark the calendar look at chrome for details
    public class EventDecorator implements DayViewDecorator {

        private final ArrayList<CalendarDay> dates;
        private final Context context;

        public EventDecorator(Context context, ArrayList<CalendarDay> dates) {
            this.dates = dates;
            this.context = context;
        }

        @Override
        public boolean shouldDecorate(CalendarDay day) {
            return dates.contains(day);
        }

        @Override
        public void decorate(DayViewFacade view) {
            Drawable drawable = ContextCompat.getDrawable(context,R.drawable.calcircleselector);
            assert drawable != null;
            view.setBackgroundDrawable(drawable);
        }
    }
    public void display_left_right(View view){
        progressBar.setVisibility(View.VISIBLE);
        startActivity(new Intent( schedule.this, left_right.class));

    }
    public void display_home(View view){
        progressBar.setVisibility(View.VISIBLE);
        startActivity(new Intent( schedule.this, mainactivity.class));
    }
}
