package com.example.hemiplegia;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;


public class videoview extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private DatabaseReference mDatabase;
    private String Paralysis = "RIGHT";


    public void onCreate(@Nullable Bundle  savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.videoview);
        mDatabase = FirebaseDatabase.getInstance().getReference("Reports");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    HashMap<String, Object> dataMap = (HashMap<String, Object>) dataSnapshot.getValue();
                    Paralysis = String.valueOf(dataMap.get("Hemiplegia"));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Paralysis = "LEFT";
                Toast.makeText(getApplicationContext(), "Some Errors Have Occurred", Toast.LENGTH_LONG).show();
            }
        });
        if (Paralysis.equalsIgnoreCase("right")) {
                    right_video();
        } else {
                    left_video();
        }
        VideoView collapse = findViewById(R.id.the_videoView);
    }
    public void left_video() {
        VideoView left = findViewById(R.id.the_videoView);
        String fileName = "android.resource://" + getPackageName() + "/" + R.raw.leftwebm;;
        left.setVideoURI(Uri.parse(fileName));
        left.setVisibility(View.VISIBLE);
        left.start();

    }
    public void press_stop(View view){
        startActivity(new Intent(videoview.this, left_right.class));
        finish();
    }

    public void right_video() {
        VideoView right = findViewById(R.id.the_videoView);
        String fileName = "android.resource://"+  getPackageName() + "/" + R.raw.rightwebm;
        right.setVideoURI(Uri.parse(fileName));
        right.setVisibility(View.VISIBLE);
        right.start();
    }
}
