package com.example.hemiplegia;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class registration_researchers extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private DatabaseReference mDatabase;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_page_researchers);

        firebaseAuth = FirebaseAuth.getInstance();

        //mDatabase = FirebaseDatabase.getInstance().getReference("patients");
        //mDatabase = FirebaseDatabase.getInstance().getReference("Reports");
        //Change database ^
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
    // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Jobs, android.R.layout.simple_spinner_item);
    // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    // Apply the adapter to the spinner
        spinner.setAdapter(adapter);
    }

    public void RegisterUser(View view) {
        final String email = ((EditText) findViewById(R.id.email_reg)).getText().toString();
        final String First_name = ((EditText) findViewById(R.id.fname)).getText().toString();
        final String Surname = ((EditText) findViewById(R.id.surname)).getText().toString();
        final String Hemiplegia = ((EditText) findViewById(R.id.hemiplegia)).getText().toString();
        String password = ((EditText) findViewById(R.id.reg_password)).getText().toString();
        String Confirm_Password = ((EditText) findViewById(R.id.confirmPassword)).getText().toString();
        if (Confirm_Password.equals(password)) {
            boolean fill = isItEmpty(email, password);
            boolean isFound = emailAt(email); //search for @
            //Creating new user
            boolean connection = checkConnection(getSystemService(Context.CONNECTIVITY_SERVICE));
            if (fill != true && connection != false) {
                if (isFound == true) {
                    firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(registration_researchers.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(registration_researchers.this, "Successfully Registered", Toast.LENGTH_LONG).show();
                                //add to database
                                //mDatabase.child("email").setValue(email);
                                //mDatabase.child("First name").setValue(First_name);
                                //mDatabase.child("Surname").setValue(Surname);
                                //mDatabase.child("Hemiplegia").setValue(Hemiplegia);
                                startActivity(new Intent(registration_researchers.this, mainactivity.class));
                            } else {
                                FirebaseAuthException e = (FirebaseAuthException) task.getException();
                                Toast.makeText(registration_researchers.this, "Unsuccessfully Registration " + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }

                    });


                } else {
                    Toast.makeText(registration_researchers.this, "Email does not contain '@'", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            Toast.makeText(registration_researchers.this, "Passwords Don't Match", Toast.LENGTH_LONG).show();
        }
    }

    public boolean emailAt(String email) {
        return email.contains("@"); //true
    }

    public boolean isItEmpty(String email, String password) {
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(registration_researchers.this, "Please enter email", Toast.LENGTH_LONG).show();
            return true;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(registration_researchers.this, "Please enter password", Toast.LENGTH_LONG).show();
            return true;
        }
        return false;
    }

    public boolean checkConnection(Object obj) {
        ConnectivityManager connectivityManager = (ConnectivityManager) obj;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo !=null&&activeNetworkInfo.isConnected();
        //should return true
    }

    public void logo_login(View view){
        startActivity(new Intent( registration_researchers.this, loginactivity.class));
    }
}
