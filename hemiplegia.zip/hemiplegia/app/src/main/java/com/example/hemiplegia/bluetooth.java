package com.example.hemiplegia;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Set;

public class bluetooth extends AppCompatActivity {
    private static final String App_name= "Hemiplegia";
    UUID MY_UUID = UUID.fromString("6fb5cb33-88cd-45f5-ba9f-1d8f6a11f288");

    static final int STATE_lISTENING = 1;
    static final int STATE_CONNECTING = 2;
    static final int STATE_CONNECTED = 3;
    static final int STATE_CONNECTION_FAILED = 4;
    static final int STATE_RECEIVED = 5;

    int request_enable_bt = 1;
    // essential ^
    BluetoothAdapter myBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    BluetoothDevice[] btArray;

    SendRecieve sendrecieve;
    TextView textView;
    TextView status;
    //handy to find ^
    //oncreate begins
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.paradigm);
        status = (TextView) findViewById(R.id.Status);
        textView = (TextView) findViewById(R.id.textView2);
        Thread2 t = new Thread2();
        t.start();

        //Adapter means it has bluetooth
        if (myBluetoothAdapter == null) {
            //device does not support bluetooth
        } else {
            if (!myBluetoothAdapter.isEnabled()) {
                //ask for it to be enabled
                startActivityForResult();
            }
        }
        ImplementListeners();
    }
    public void ImplementListeners(){
        Set<BluetoothDevice> BTDevices = myBluetoothAdapter.getBondedDevices();
        String[] strings = new String[BTDevices.size()];
        btArray = new  BluetoothDevice[BTDevices.size()];
        int index = 0;
        if (BTDevices.size() > 0) {
            for (BluetoothDevice device : BTDevices) {
                btArray[index] = device;
                strings[index] = device.getName();
                index++;
            }

        }//set to the spinner
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, strings);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);

    }
    public void create_serverclass(View view){
        ServerClass serverClass = new ServerClass();
        serverClass.start();
    }

    public void create_Clientclass(View view){
        Spinner spinner = findViewById(R.id.spinner2);
        int spinner_pos = spinner.getSelectedItemPosition();
        ClientClass clientClass = new ClientClass(btArray[spinner_pos]);
        clientClass.start();

        status.setText("Connecting");
    }

    private void startActivityForResult() {
        Intent enableBluetoothIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(enableBluetoothIntent, request_enable_bt);

    }

    public void discoverable(View view) {
        Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        startActivity(discoverableIntent);
    }

    //display results from Connection
    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            // displays the message from the thread to the handler
           switch (msg.what){
               case STATE_lISTENING:
                    status.setText("Listening");
                    break;

               case STATE_CONNECTING:
                    status.setText("Connecting");
                    break;

               case STATE_CONNECTED:
                    status.setText("Connected");
                    break;

               case STATE_CONNECTION_FAILED:
                    status.setText("Connection Failed");
                    break;

               case STATE_RECEIVED:
                    status.setText("Message Recieved");
                    byte[] readBuffer = (byte[]) msg.obj;
                    String tempMag = new String(readBuffer,0,msg.arg1);
                    textView.setText(tempMag);
                    break;
           }
           return true;
        }
    });
    private class Thread2 extends Thread {
        public void run() {
            for (int i = 0; i < 50; i++) {
                Message message = Message.obtain();
                message.arg1 =i;
                //sends message to handler
                handler.sendMessage(message);
                //anything set as message is sent to the screen find way to send serial data.
                try {
                    sleep(500);
                } catch (InterruptedException e){
                    e.printStackTrace();
                }
            }

        }
    }
//Class Declaration
    private class ServerClass extends Thread{
        private BluetoothServerSocket serverSocket;
        public ServerClass(){
            try {
                serverSocket=myBluetoothAdapter.listenUsingRfcommWithServiceRecord(App_name,MY_UUID);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        public void run(){
                BluetoothSocket socket = null;
                while (socket == null){
                    try {
                        Message message = Message.obtain();
                        message.what=STATE_CONNECTING;
                        handler.sendMessage(message);
                        socket=serverSocket.accept();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Message message = Message.obtain();
                        message.what=STATE_CONNECTION_FAILED;
                        handler.sendMessage(message);
                    }
                    if (socket!=null){
                        Message message = Message.obtain();
                        message.what=STATE_CONNECTED;
                        handler.sendMessage(message);
                        sendrecieve = new SendRecieve(socket);
                        sendrecieve.start();

                        break;
                    }
                }

        }

    }

    private class ClientClass extends Thread {
        private BluetoothDevice device;
        private BluetoothSocket socket;

        public ClientClass (BluetoothDevice device1){
            device = device1;
            try {
                socket = device1.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        public void run (){
            try {
                socket.connect();
                Message message = Message.obtain();
                message.what = STATE_CONNECTED;
                handler.sendMessage(message);

                sendrecieve = new SendRecieve(socket);
                sendrecieve.start();
            } catch (IOException e) {
                e.printStackTrace();
                Message message = Message.obtain();
                message.what = STATE_CONNECTION_FAILED;
                handler.sendMessage(message);
            }
        }
    }

    private class SendRecieve extends Thread{
        private BluetoothSocket bluetoothSocket;
        private InputStream inputStream;
        private OutputStream outputStream;

        public SendRecieve(BluetoothSocket socket){
            bluetoothSocket = socket;
            InputStream tempIn = null;
            OutputStream tempOut = null;

            try {
                tempIn=bluetoothSocket.getInputStream();
                tempOut=bluetoothSocket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            inputStream = tempIn;
            outputStream = tempOut;
        }
        public void run() {
            byte[] buffer = new byte[1024];
            int bytes;

            while(true)
            {
                try {
                    bytes = inputStream.read(buffer);
                    handler.obtainMessage(STATE_RECEIVED, bytes,-1, buffer ).sendToTarget();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        public void write(byte[] bytes){
            try {
                outputStream.write(bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}


