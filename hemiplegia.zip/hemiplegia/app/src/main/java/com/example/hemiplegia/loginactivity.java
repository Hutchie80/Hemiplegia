package com.example.hemiplegia;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

public class loginactivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private View view;
    private int count = 0 ;
    private String msg;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Login

        final Button loginButton = findViewById(R.id.Login);
        final Button registerButton = findViewById(R.id.Register);
        firebaseAuth = FirebaseAuth.getInstance();
        boolean validUser = false;
        FirebaseInstanceId.getInstance()
                .getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
            @Override
            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                if (!task.isSuccessful()) {
                    Log.w( "getInstanceId failed", task.getException());
                    return;
                }

                // Get new Instance ID token
                String token = task.getResult().getToken();

                // Log and toast
                msg = getString(R.string.registering_message) + token;
                Log.d("msgToken:", msg);
                Toast.makeText(loginactivity.this, msg, Toast.LENGTH_SHORT).show();
            }});
        //get instance id
        // EditText Token = findViewById(R.id.Email);
        //Token.setText(msg);
    }

    public void goLogin(View view) {


        final String email = ((EditText) findViewById(R.id.Email)).getText().toString();
        String password = ((EditText) findViewById(R.id.Password)).getText().toString();

        //Creating new user
        boolean fill = isItEmpty(email, password); //check is not empty
        boolean connection = checkConnection(getSystemService(Context.CONNECTIVITY_SERVICE)); //check internet connection
        boolean isFound = emailAt(email); //search for @
        if (fill == false && connection == true) {
            if (isFound = true) {
                firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(loginactivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(loginactivity.this, "Login Successful", Toast.LENGTH_LONG).show();
                            startActivity(new Intent(getApplicationContext(), mainactivity.class));
                            finish();
                        } else if (count > 10 ){
                            FirebaseUser user = firebaseAuth.getCurrentUser();
                           try {
                               // Email sent.
                               user.sendEmailVerification();
                               count =0;
                           } catch (Exception e) {
                               e.printStackTrace();
                           }
                           String limit ="You have attempted to sign in " + count+ ". Your have surpassed the limit of sign in attempts click link to reset password: ";
                           Toast.makeText(loginactivity.this, limit ,Toast.LENGTH_LONG).show();
                           if (count > 0) { count = 0; }
                        } else {
                            Toast.makeText(loginactivity.this, "Login Error", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }
    }
    public boolean isItEmpty(String email, String password) {
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(loginactivity.this, "Please enter email", Toast.LENGTH_LONG).show();
            return true;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(loginactivity.this, "Please enter password", Toast.LENGTH_LONG).show();
            return true;
        }
        return false;
    }

    public boolean emailAt(String email) {
        return email.contains("@"); //true
    }

    public boolean checkConnection(Object obj) {
        ConnectivityManager connectivityManager = (ConnectivityManager) obj;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo !=null&&activeNetworkInfo.isConnected();
        //should return true
    }
    public void goRegister(View view){
        startActivity(new Intent(loginactivity.this, registration.class));
        finish();
    }
}
