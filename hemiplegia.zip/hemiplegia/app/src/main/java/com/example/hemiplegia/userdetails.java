package com.example.hemiplegia;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class userdetails extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private DatabaseReference mDatabase;
    private EditText UploadID;
    private EditText uploadFname;
    private EditText uploadSurname;
    private EditText uploadEmail;
    private EditText uploadParalysis;
    private Button Edit_report;
    private Button Save_report;
    private Button Remove_report;
    private boolean Loaded;


    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_details);
        firebaseAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("Reports");
        UploadID = (EditText) findViewById(R.id.AccountID_Upload);
        uploadFname = (EditText) findViewById(R.id.FName_Upload);
        uploadSurname = (EditText) findViewById(R.id.Surname_Upload);
        uploadEmail = (EditText) findViewById(R.id.Email_Upload);
        uploadParalysis = (EditText) findViewById(R.id.Para_Upload);
        Edit_report = (Button) findViewById(R.id.Edit);
        Save_report = (Button) findViewById(R.id.save);
        Remove_report = (Button) findViewById(R.id.Remove) ;
        // Toast.makeText(userdetails.this, "Not Ready Yet", Toast.LENGTH_LONG).show();
        //pass json from firebase into appropriate fields check police scanner for vague details.
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
        String UserID = currentUser.getUid();
        basicRead(UserID);
    }

    public void edit_Details(View view) {
        Save_report.setVisibility(View.VISIBLE);
        Save_report.setClickable(true);
        Edit_report.setVisibility(View.INVISIBLE);
        Remove_report.setClickable(true);
        //edit disappears and save appears
        uploadFname.setEnabled(true);
        uploadSurname.setEnabled(true);
        uploadEmail.setEnabled(true);
        uploadParalysis.setEnabled(true);
    }

    public void setSave_report(View view) {
        Save_report.setVisibility(View.INVISIBLE);
        Edit_report.setVisibility(View.VISIBLE);
        Remove_report.setClickable(false);
        final String Account =  UploadID.getText().toString();
        final String email = uploadEmail.getText().toString();
        final String First_name = uploadFname.getText().toString();
        final String Surname = uploadSurname.getText().toString();
        final String Hemiplegia = uploadParalysis.getText().toString();
        if (Loaded == true) {
            boolean isFound = emailAt(email); //search for @
            boolean connection = checkConnection(getSystemService(Context.CONNECTIVITY_SERVICE));
            if (connection != false) {
                if (isFound == true) {
                                Toast.makeText(userdetails.this, "Saved", Toast.LENGTH_LONG).show();
                                //add to database
                                mDatabase.child("User ID").setValue(Account);
                                mDatabase.child("email").setValue(email);
                                mDatabase.child("First name").setValue(First_name);
                                mDatabase.child("Surname").setValue(Surname);
                                mDatabase.child("Hemiplegia").setValue(Hemiplegia);
                                startActivity(new Intent(userdetails.this, mainactivity.class));
                } else {
                                Toast.makeText(userdetails.this, "Unsuccessfully Save " , Toast.LENGTH_LONG).show();
                }
            }

        }
    }


    public void Remove_Details(View view) {
        if (Remove_report.getLinksClickable() == true) {
            Remove_report.setVisibility(View.INVISIBLE);
            FirebaseUser currentUser = firebaseAuth.getInstance().getCurrentUser();
            Toast.makeText(userdetails.this, "Details Removed \n You will now be signed out", Toast.LENGTH_LONG).show();
            currentUser.delete();
            startActivity(new Intent(userdetails.this, loginactivity.class));
            finish();
        } else {
            Toast.makeText(userdetails.this, "Click Edit to Remove Account", Toast.LENGTH_LONG).show();
        }
    }

    public void basicRead(final String UserID){
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    HashMap<String,Object> dataMap = (HashMap<String, Object>) dataSnapshot.getValue();
                    try {
                        String email = String.valueOf(dataMap.get("email"));
                        String account = UserID;
                        String first = String.valueOf(dataMap.get("First name"));
                        String surname = String.valueOf(dataMap.get("Surname"));
                        String Paralysis = String.valueOf(dataMap.get("Hemiplegia"));
                        //load into page
                        UploadID.setText(account);
                        uploadFname.setText(first);
                        uploadSurname.setText(surname);
                        uploadEmail.setText(email);
                        uploadParalysis.setText(Paralysis);
                        Loaded = true;
                    } catch (ClassCastException err){
                        Toast.makeText(getApplicationContext(),"Some Errors Have Occurred",Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),"Some Errors Have Occurred (Failed to Read)",Toast.LENGTH_LONG).show();
            }
        });

    }
    public boolean emailAt(String email) {
        return email.contains("@"); //true
    }

    public boolean isItEmpty(String email, String password) {
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(userdetails.this, "Please enter email", Toast.LENGTH_LONG).show();
            return true;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(userdetails.this, "Please enter password", Toast.LENGTH_LONG).show();
            return true;
        }
        return false;
    }

    public boolean checkConnection(Object obj) {
        ConnectivityManager connectivityManager = (ConnectivityManager) obj;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo !=null&&activeNetworkInfo.isConnected();
        //should return true
    }

}

