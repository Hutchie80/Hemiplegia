package com.example.hemiplegia;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.HashMap;


public class reports extends AppCompatActivity {
    private DatabaseReference mDatabase;
    private LineGraphSeries<DataPoint> series;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //get information from results json and input that into graph view check below comments for details.
        //Toast.makeText(this, "Page Unfinished (Blame SAM!", Toast.LENGTH_LONG);
        setContentView(R.layout.scheduled_reports);
        mDatabase = FirebaseDatabase.getInstance().getReference("Reports");
        // Toast.makeText(reports.this, "Not Ready Yet", Toast.LENGTH_LONG).show();

        //How to set Graph up below
        GraphView graph = findViewById(R.id.graph_report);
        GenerateGraph();
        /*
        series = new LineGraphSeries<DataPoint>(new DataPoint[] {
                new DataPoint(0, 97),
                new DataPoint( 1, 104),
                new DataPoint (2, 1023),
                new DataPoint (3, 98),
                new DataPoint (4, 957),
                new DataPoint( 5, 808),
                new DataPoint (6, 111),
                new DataPoint (7, 80),
                new DataPoint(8, 786),
                new DataPoint(9, 1023),
        });*/
        //^ use this to then implement the data from FireBase
        graph.addSeries(series);
        //seriesData="0=5;2=5;3=0;4=2"
    }
    public void GenerateGraph(){
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()){
                    HashMap<String,Object> dataMap = (HashMap<String, Object>) dataSnapshot.getValue();
                    try {
                        String Results  = String.valueOf(dataMap.get("First"));
                        String[] resultsArray = Results.split(",");
                        int[] result = new int[resultsArray.length];
                        for (int length = 0 ; length < resultsArray.length; length++){
                            result[length] = Integer.parseInt(resultsArray[length]);
                            series = new LineGraphSeries<DataPoint>(new DataPoint[] {
                                    new DataPoint(length, result[length])
                            });
                        }
                    } catch (ClassCastException err){
                        Toast.makeText(getApplicationContext(),"Some Errors Have Occurred",Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),"Some Errors Have Occurred (Failed to Read)",Toast.LENGTH_LONG).show();
            }
        });
    }


    public void HomeButton(View view){
        startActivity(new Intent( reports.this, mainactivity.class));
    }
}
