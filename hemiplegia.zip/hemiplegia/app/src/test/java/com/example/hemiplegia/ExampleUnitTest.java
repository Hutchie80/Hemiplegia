package com.example.hemiplegia;

import android.widget.CalendarView;

import com.prolificinteractive.materialcalendarview.CalendarDay;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
    @Test
    public void isitempty (){
        //string is empty return true;
        String email = "";
        String password = "";
        loginactivity testLogin = new loginactivity();
        boolean gotText = testLogin.isItEmpty(email,password);
        assertEquals(true, gotText );
    }
    @Test
    public void isitat () {
        //string is empty return true;
        String email = "";
        loginactivity testLogin = new loginactivity();
        boolean gotText = testLogin.emailAt(email);
        assertEquals(false, gotText);
    }
    //internet return true
    @Test
    public void isitemptyreg (){
        //string is empty return true;
        String email = "";
        String password = "";
        registration testLogin = new registration();
        boolean gotText = testLogin.isItEmpty(email,password);
        assertEquals(true, gotText );
    }
    @Test
    public void isitatreg () {
        //string is empty return true;
        String email = "";
        registration testLogin = new registration();
        boolean gotText = testLogin.emailAt(email);
        assertEquals(false, gotText);
    }
    @Test
    public void isitatud () {
        //string is empty return true;
        String email = "";
        userdetails testLogin = new userdetails();
        boolean gotText = testLogin.emailAt(email);
        assertEquals(false, gotText);
    }
    @Test
    public void isitemptyud (){
        //string is empty return true;
        String email = "";
        String password = "";
        userdetails testLogin = new userdetails();
        boolean gotText = testLogin.isItEmpty(email,password);
        assertEquals(true, gotText );
    }
    @Test
    public void isitdecorator(){
        schedule testshedule = new schedule();
        CalendarDay Date = CalendarDay.today();
        ArrayList<CalendarDay> day = new ArrayList<CalendarDay>();
        day.add(Date);
        schedule.EventDecorator test = new schedule.EventDecorator(this, day);
        test.EventDecorator(this, day );
        boolean decorate = test.shouldDecorate(Date);
        assertEquals(true, decorate );

    }
    @Test
    public void isitBluetoothname(){
        left_right test = new left_right();
        String gotName = test.getLocalBluetoothName();
        boolean empty = gotName.isEmpty();
        assertEquals(false, empty );
    }
    @Test
    public void isitleftorright() {
        left_right test = new left_right();
        boolean coulditbetrue = test.left_or_right();
        assertEquals(true, coulditbetrue);
    }
}